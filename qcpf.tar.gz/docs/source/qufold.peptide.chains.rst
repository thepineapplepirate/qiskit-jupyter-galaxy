qufold.peptide.chains package
=============================

.. automodule:: qufold.peptide.chains
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------


.. automodule:: qufold.peptide.chains.base_chain
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: qufold.peptide.chains.main_chain
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: qufold.peptide.chains.side_chain
   :members:
   :undoc-members:
   :show-inheritance:
