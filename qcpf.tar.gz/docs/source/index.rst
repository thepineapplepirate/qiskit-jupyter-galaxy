.. protein-folding-qc documentation master file, created by
   sphinx-quickstart on Tue Apr  2 10:12:45 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to protein-folding-qc's documentation!
==============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules
   GitHub <https://github.com/ruihao-li/protein-folding-qc>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
