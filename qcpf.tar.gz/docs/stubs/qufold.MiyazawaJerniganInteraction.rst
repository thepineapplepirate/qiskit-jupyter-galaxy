﻿qufold.MiyazawaJerniganInteraction
==================================

.. currentmodule:: qufold

.. autoclass:: MiyazawaJerniganInteraction

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MiyazawaJerniganInteraction.__init__
      ~MiyazawaJerniganInteraction.calculate_energy_matrix
   
   

   
   
   