﻿qufold.utils.ProteinShapeDecoder
================================

.. currentmodule:: qufold.utils

.. autoclass:: ProteinShapeDecoder

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ProteinShapeDecoder.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ProteinShapeDecoder.main_turns
      ~ProteinShapeDecoder.side_turns
   
   