﻿qufold.SideChain
================

.. currentmodule:: qufold

.. autoclass:: SideChain

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SideChain.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~SideChain.beads_list
      ~SideChain.residue_sequence
   
   