﻿qufold.RandomInteraction
========================

.. currentmodule:: qufold

.. autoclass:: RandomInteraction

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~RandomInteraction.__init__
      ~RandomInteraction.calculate_energy_matrix
   
   

   
   
   