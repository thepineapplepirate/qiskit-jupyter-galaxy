﻿qufold.InvalidSizeException
===========================

.. currentmodule:: qufold

.. autoexception:: InvalidSizeException