﻿qufold.InvalidResidueException
==============================

.. currentmodule:: qufold

.. autoexception:: InvalidResidueException