﻿qufold.Peptide
==============

.. currentmodule:: qufold

.. autoclass:: Peptide

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Peptide.__init__
      ~Peptide.get_side_chain_hot_vector
      ~Peptide.get_side_chains
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Peptide.get_main_chain
   
   