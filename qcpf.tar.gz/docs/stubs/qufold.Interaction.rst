﻿qufold.Interaction
==================

.. currentmodule:: qufold

.. autoclass:: Interaction

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Interaction.__init__
      ~Interaction.calculate_energy_matrix
   
   

   
   
   