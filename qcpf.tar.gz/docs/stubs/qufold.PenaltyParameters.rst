﻿qufold.PenaltyParameters
========================

.. currentmodule:: qufold

.. autoclass:: PenaltyParameters

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PenaltyParameters.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~PenaltyParameters.penalty_1
      ~PenaltyParameters.penalty_back
      ~PenaltyParameters.penalty_chiral
   
   