﻿qufold.MainChain
================

.. currentmodule:: qufold

.. autoclass:: MainChain

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MainChain.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MainChain.beads_list
      ~MainChain.main_chain_residue_sequence
      ~MainChain.residue_sequence
   
   