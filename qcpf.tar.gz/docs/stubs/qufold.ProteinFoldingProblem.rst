﻿qufold.ProteinFoldingProblem
============================

.. currentmodule:: qufold

.. autoclass:: ProteinFoldingProblem

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ProteinFoldingProblem.__init__
      ~ProteinFoldingProblem.interpret
      ~ProteinFoldingProblem.interpret_bitstring
      ~ProteinFoldingProblem.interpret_new
      ~ProteinFoldingProblem.qubit_op
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ProteinFoldingProblem.peptide
      ~ProteinFoldingProblem.unused_qubits
   
   