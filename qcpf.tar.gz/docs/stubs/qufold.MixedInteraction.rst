﻿qufold.MixedInteraction
=======================

.. currentmodule:: qufold

.. autoclass:: MixedInteraction

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MixedInteraction.__init__
      ~MixedInteraction.calculate_energy_matrix
   
   

   
   
   