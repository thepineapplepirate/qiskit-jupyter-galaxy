﻿qufold.InvalidSideChainException
================================

.. currentmodule:: qufold

.. autoexception:: InvalidSideChainException