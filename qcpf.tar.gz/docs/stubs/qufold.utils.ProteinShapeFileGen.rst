﻿qufold.utils.ProteinShapeFileGen
================================

.. currentmodule:: qufold.utils

.. autoclass:: ProteinShapeFileGen

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ProteinShapeFileGen.__init__
      ~ProteinShapeFileGen.generate_main_positions
      ~ProteinShapeFileGen.generate_side_positions
      ~ProteinShapeFileGen.get_xyz_data
      ~ProteinShapeFileGen.save_xyz_file
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ProteinShapeFileGen.COORDINATES
      ~ProteinShapeFileGen.main_positions
      ~ProteinShapeFileGen.side_positions
   
   