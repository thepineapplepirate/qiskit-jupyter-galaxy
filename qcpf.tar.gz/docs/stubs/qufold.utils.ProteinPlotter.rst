﻿qufold.utils.ProteinPlotter
===========================

.. currentmodule:: qufold.utils

.. autoclass:: ProteinPlotter

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ProteinPlotter.__init__
      ~ProteinPlotter.get_figure
   
   

   
   
   