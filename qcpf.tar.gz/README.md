# protein-folding-qc

[![Dev](https://img.shields.io/badge/docs-dev-blue.svg)](https://ruihao-li.github.io/protein-folding-qc/index.html)

Quantum Computing-based coarse-grained predictions of protein conformations on lattices.   
